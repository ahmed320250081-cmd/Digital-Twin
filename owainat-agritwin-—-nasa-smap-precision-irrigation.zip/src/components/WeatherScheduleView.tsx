import { AlertTriangle, CheckCircle2, CloudSun, Droplets, Info, Wind } from 'lucide-react';
import { FarmPlot, FarmSettings, WeatherAlert, WeatherForecast } from '../types/farm';
import { OWAINAT_CENTER, predictCropYield } from '../utils/agronomy';

interface WeatherScheduleViewProps {
  weather: WeatherForecast;
  alerts: WeatherAlert[];
  plots: FarmPlot[];
  settings: FarmSettings;
  onToggleIrrigation: (plotId: string, nextIrrigating: boolean, nextFlow: number) => void;
}

export function WeatherScheduleView({
  weather,
  alerts,
  plots,
  settings,
  onToggleIrrigation,
}: WeatherScheduleViewProps) {
  return (
    <div className="flex-1 overflow-y-auto bg-[#0B1117] px-6 py-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <h1 className="text-2xl font-semibold text-slate-100 font-display">
              Localized Weather Alerts &amp; Irrigation Schedule
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Hyper-arid meteorological telemetry for {OWAINAT_CENTER.lat.toFixed(4)}° N,{' '}
              {OWAINAT_CENTER.lng.toFixed(4)}° E · Evaporation lockout set at{' '}
              {settings.evapLockoutTempC}°C.
            </p>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Source: {weather.source === 'open-meteo' ? 'Live Open-Meteo API' : 'Owainat Climatology Baseline'}
          </div>
        </div>

        {/* Current Conditions Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-lg bg-[#111923] border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Air Temperature</span>
              <CloudSun className="w-4 h-4 text-amber-400" aria-hidden="true" />
            </div>
            <div className="mt-1.5 text-2xl font-semibold font-mono tabular-nums text-slate-100">
              {weather.currentTempC.toFixed(1)} °C
            </div>
            <div className="mt-1 text-xs font-mono text-slate-400 tabular-nums">
              Range: {weather.dailyMinTempC.toFixed(1)}° – {weather.dailyMaxTempC.toFixed(1)}°C
            </div>
          </div>

          <div className="p-4 rounded-lg bg-[#111923] border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Desert Wind Speed</span>
              <Wind className="w-4 h-4 text-cyan-400" aria-hidden="true" />
            </div>
            <div className="mt-1.5 text-2xl font-semibold font-mono tabular-nums text-slate-100">
              {weather.currentWindKmh} km/h
            </div>
            <div className="mt-1 text-xs text-slate-400">
              {weather.currentWindKmh >= 28 ? 'Drift caution active' : 'Low spray drift'}
            </div>
          </div>

          <div className="p-4 rounded-lg bg-[#111923] border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Relative Humidity</span>
              <Droplets className="w-4 h-4 text-emerald-400" aria-hidden="true" />
            </div>
            <div className="mt-1.5 text-2xl font-semibold font-mono tabular-nums text-slate-100">
              {weather.currentHumidityPct}%
            </div>
            <div className="mt-1 text-xs text-slate-400">Hyper-arid VPD index</div>
          </div>

          <div className="p-4 rounded-lg bg-[#111923] border border-slate-800">
            <div className="text-xs text-slate-400">Solar Irradiance</div>
            <div className="mt-1.5 text-2xl font-semibold font-mono tabular-nums text-amber-300">
              {weather.currentSolarWm2}
              <span className="text-xs font-normal text-slate-400 ml-1">W/m²</span>
            </div>
            <div className="mt-1 text-xs text-slate-400">Powers Aquifer PV Microgrid</div>
          </div>
        </div>

        {/* Weather Alerts List (Non-hue-only: explicit severity icon + text) */}
        <section aria-label="Active localized weather alerts" className="space-y-3">
          <h2 className="text-base font-semibold text-slate-100">
            Active Field Weather Alerts
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {alerts.map((alert) => {
              const isCritical = alert.severity === 'critical';
              const isWarning = alert.severity === 'warning';
              return (
                <article
                  key={alert.id}
                  className="p-4 rounded-lg bg-[#111923] border border-slate-800 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs mb-2">
                      <span
                        className={`inline-flex items-center gap-1.5 font-semibold ${
                          isCritical
                            ? 'text-rose-400'
                            : isWarning
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                        }`}
                      >
                        {isCritical ? (
                          <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
                        ) : isWarning ? (
                          <Info className="w-3.5 h-3.5" aria-hidden="true" />
                        ) : (
                          <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                        )}
                        <span>
                          {isCritical ? 'Critical Alert' : isWarning ? 'Warning' : 'Advisory'}
                        </span>
                      </span>
                      <span className="font-mono text-slate-300 tabular-nums">
                        {alert.metricValue}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-slate-100">{alert.title}</h3>
                    <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                      {alert.description}
                    </p>
                  </div>
                  <div className="pt-2.5 border-t border-slate-800 text-[11px] font-mono text-slate-400">
                    Action Window: {alert.actionWindow}
                  </div>
                </article>
              );
            })}
          </div>
        </section>

        {/* 24-Hour Meteorological & ET0 Profile */}
        <section className="rounded-lg bg-[#111923] border border-slate-800 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-800">
            <h2 className="text-base font-semibold text-slate-100">
              24-Hour Evapotranspiration &amp; Pivot Lockout Windows
            </h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 divide-y sm:divide-y-0 sm:divide-x divide-slate-800">
            {weather.hourly.slice(0, 8).map((hr) => {
              const lockedOut = hr.tempC >= settings.evapLockoutTempC;
              return (
                <div
                  key={hr.timeIso}
                  className="p-3.5 space-y-1.5"
                >
                  <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                    <span>{hr.hourLabel}</span>
                    <span className={lockedOut ? 'text-rose-400' : 'text-emerald-400'}>
                      {lockedOut ? 'Lockout' : 'Optimal'}
                    </span>
                  </div>
                  <div className="text-base font-semibold font-mono tabular-nums text-slate-100">
                    {hr.tempC.toFixed(1)}°C
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                    Wind {hr.windKmh} km/h · ET₀ {hr.et0MmHr.toFixed(2)} mm
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Real-Time Plot Irrigation Operations Queue */}
        <section className="rounded-lg bg-[#111923] border border-slate-800 overflow-hidden">
          <div className="p-4 border-b border-slate-800">
            <h2 className="text-base font-semibold text-slate-100">
              Center-Pivot Irrigation Dispatch Queue
            </h2>
            <p className="text-xs text-slate-400">
              Toggle active irrigation pumps based on SMAP moisture targets and weather advisories.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-medium text-slate-400 bg-[#0E151E]">
                  <th className="py-2.5 px-4">Plot</th>
                  <th className="py-2.5 px-3">Crop</th>
                  <th className="py-2.5 px-3 text-right">Root Moisture</th>
                  <th className="py-2.5 px-3 text-right">Target</th>
                  <th className="py-2.5 px-3 text-right">Flow (m³/h)</th>
                  <th className="py-2.5 px-3">Agronomy Guidance</th>
                  <th className="py-2.5 px-4 text-right">Pump Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {plots.map((plot) => {
                  const pred = predictCropYield(plot);
                  return (
                    <tr key={plot.id} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 font-mono font-medium text-cyan-300">
                        {plot.plotCode}
                      </td>
                      <td className="py-2.5 px-3 text-slate-200">{plot.cropType}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">
                        {plot.smapRootMoisturePct}%
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                        {plot.targetMoisturePct}%
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">
                        {plot.irrigating ? plot.flowRateM3Hr : 0}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 max-w-md">{pred.recommendation}</td>
                      <td className="py-2.5 px-4 text-right">
                        <button
                          type="button"
                          disabled={plot.cropType === 'Fallow'}
                          onClick={() =>
                            onToggleIrrigation(
                              plot.id,
                              !plot.irrigating,
                              Math.round(plot.sustainabilityCapM3Hr * 0.85),
                            )
                          }
                          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap disabled:opacity-40 ${
                            plot.irrigating
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 hover:bg-amber-500/25'
                              : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
                          }`}
                        >
                          {plot.cropType === 'Fallow'
                            ? 'Fallow'
                            : plot.irrigating
                              ? 'Stop Pump'
                              : 'Start Pump'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
