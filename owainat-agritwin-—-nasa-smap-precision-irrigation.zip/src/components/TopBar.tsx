import { ShieldCheck, UserCheck } from 'lucide-react';
import { UserProfile, UserRole, WorkspaceTab } from '../types/farm';

interface TopBarProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
  effectiveRole: UserRole;
  authUser: UserProfile | null;
  onOpenRolePanel: () => void;
}

const NAV_ITEMS: Array<{ id: WorkspaceTab; label: string }> = [
  { id: 'twin', label: '3D Digital Twin' },
  { id: 'analytics', label: 'Analytics & Yield' },
  { id: 'weather', label: 'Weather & Schedule' },
  { id: 'access', label: 'Access & Logs' },
];

export function TopBar({
  activeTab,
  onTabChange,
  effectiveRole,
  authUser,
  onOpenRolePanel,
}: TopBarProps) {
  const roleLabel = effectiveRole === 'farm_manager' ? 'Farm Manager' : 'Field Operator';

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#0B1117] border-b border-slate-800 shrink-0">
      <a
        href="#top"
        onClick={(e) => {
          e.preventDefault();
          onTabChange('twin');
        }}
        className="text-lg font-semibold tracking-tight text-slate-100 whitespace-nowrap shrink-0 font-display"
      >
        Owainat AgriTwin
      </a>

      <nav aria-label="Primary sections" className="flex items-center gap-6 overflow-x-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onTabChange(item.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-t-sm ${
                isActive
                  ? 'text-cyan-400 border-cyan-400'
                  : 'text-slate-400 border-transparent hover:text-slate-100 hover:border-slate-700'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="flex items-center shrink-0">
        <button
          type="button"
          onClick={onOpenRolePanel}
          aria-label={`Active role: ${roleLabel}. Open access and account settings`}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
        >
          {effectiveRole === 'farm_manager' ? (
            <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
          ) : (
            <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />
          )}
          <span>{authUser ? `${authUser.displayName.split(' ')[0]} · ${roleLabel}` : roleLabel}</span>
        </button>
      </div>
    </header>
  );
}
