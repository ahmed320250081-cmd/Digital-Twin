import { useState } from 'react';
import { Lock, LogIn, LogOut, ShieldCheck, UserCheck } from 'lucide-react';
import {
  FarmPlot,
  FarmSettings,
  FieldLogEntry,
  UserProfile,
  UserRole,
} from '../types/farm';

interface AccessLogsViewProps {
  authUser: UserProfile | null;
  effectiveRole: UserRole;
  onChangePreviewRole: (role: UserRole) => void;
  onSignInGoogle: () => Promise<void>;
  onSignOut: () => Promise<void>;
  authError: string | null;
  plots: FarmPlot[];
  settings: FarmSettings;
  onUpdateSettings: (next: FarmSettings) => void;
  logs: FieldLogEntry[];
  onSubmitLog: (entry: {
    plotCode: string;
    category: FieldLogEntry['category'];
    note: string;
  }) => Promise<void>;
  teamUsers: UserProfile[];
  onManagerChangeUserRole: (uid: string, role: UserRole) => Promise<void>;
}

export function AccessLogsView({
  authUser,
  effectiveRole,
  onChangePreviewRole,
  onSignInGoogle,
  onSignOut,
  authError,
  plots,
  settings,
  onUpdateSettings,
  logs,
  onSubmitLog,
  teamUsers,
  onManagerChangeUserRole,
}: AccessLogsViewProps) {
  const isManager = effectiveRole === 'farm_manager';

  const [plotCode, setPlotCode] = useState(plots[0]?.plotCode ?? 'P-01');
  const [category, setCategory] = useState<FieldLogEntry['category']>('irrigation');
  const [note, setNote] = useState('');
  const [logError, setLogError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [dailyCapDraft, setDailyCapDraft] = useState(settings.aquiferDailyCapM3);
  const [lockoutTempDraft, setLockoutTempDraft] = useState(settings.evapLockoutTempC);
  const [policySaved, setPolicySaved] = useState(false);

  const handleLogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = note.trim();
    if (trimmed.length < 3) {
      setLogError('Please enter an inspection note of at least 3 characters.');
      return;
    }
    setLogError(null);
    setSubmitting(true);
    try {
      await onSubmitLog({ plotCode, category, note: trimmed });
      setNote('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#0B1117] px-6 py-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <h1 className="text-2xl font-semibold text-slate-100 font-display">
              Role-Based Access Control &amp; Field Logs
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Firebase Authentication &amp; Firestore security rules enforce Farm Manager and Field
              Operator permissions across all center-pivot operations.
            </p>
          </div>
        </div>

        {/* Account & Role Control Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Authentication & Role Switcher */}
          <section className="lg:col-span-5 p-5 rounded-lg bg-[#111923] border border-slate-800 space-y-4">
            <h2 className="text-base font-semibold text-slate-100">
              Identity &amp; Active Role Context
            </h2>

            {authUser ? (
              <div className="p-3.5 rounded-lg bg-[#0E151E] border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-100">{authUser.displayName}</span>
                  <span className="text-xs font-mono text-cyan-400">
                    {authUser.role === 'farm_manager' ? 'Farm Manager' : 'Field Operator'}
                  </span>
                </div>
                <div className="text-xs font-mono text-slate-400">{authUser.email}</div>
                <button
                  type="button"
                  onClick={() => void onSignOut()}
                  className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-slate-400 leading-relaxed">
                  Sign in with Google to persist plot updates, sustainability policies, and field
                  inspection logs to Cloud Firestore, or switch roles below to inspect RBAC
                  permissions.
                </p>
                <button
                  type="button"
                  onClick={() => void onSignInGoogle()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors"
                >
                  <LogIn className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Sign In with Google</span>
                </button>
                {authError && (
                  <p role="alert" className="text-xs text-rose-400">
                    {authError}
                  </p>
                )}
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="text-xs font-medium text-slate-300">
                Active Role Workspace Switcher
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onChangePreviewRole('farm_manager')}
                  aria-pressed={effectiveRole === 'farm_manager'}
                  className={`flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-medium rounded-lg border transition-colors ${
                    effectiveRole === 'farm_manager'
                      ? 'bg-cyan-500/15 border-cyan-400 text-cyan-300'
                      : 'bg-[#0E151E] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Farm Manager</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangePreviewRole('field_operator')}
                  aria-pressed={effectiveRole === 'field_operator'}
                  className={`flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-medium rounded-lg border transition-colors ${
                    effectiveRole === 'field_operator'
                      ? 'bg-cyan-500/15 border-cyan-400 text-cyan-300'
                      : 'bg-[#0E151E] border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Field Operator</span>
                </button>
              </div>
            </div>

            {/* Permissions Matrix */}
            <div className="pt-3 border-t border-slate-800 text-xs space-y-1.5">
              <div className="font-medium text-slate-300 mb-2">Role Permissions Matrix</div>
              <div className="flex justify-between text-slate-400">
                <span>Toggle irrigation within aquifer cap</span>
                <span className="font-mono text-emerald-400">Manager + Operator</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Inspect SMAP, NDVI &amp; Thermal layers</span>
                <span className="font-mono text-emerald-400">Manager + Operator</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Submit field maintenance logs</span>
                <span className="font-mono text-emerald-400">Manager + Operator</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Modify crop rotations &amp; aquifer caps</span>
                <span className="font-mono text-amber-300">Manager Only</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Assign team member roles</span>
                <span className="font-mono text-amber-300">Manager Only</span>
              </div>
            </div>
          </section>

          {/* Estate Sustainability Governance (Manager Only) */}
          <section className="lg:col-span-7 p-5 rounded-lg bg-[#111923] border border-slate-800 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-slate-100">
                Aquifer Sustainability Thresholds
              </h2>
              {!isManager && (
                <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                  <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Locked for Field Operator</span>
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="estate-cap-input" className="block text-xs text-slate-400 mb-1.5">
                  Daily Nubian Aquifer Extraction Cap (m³/day)
                </label>
                <input
                  id="estate-cap-input"
                  type="number"
                  min={10000}
                  max={100000}
                  step={1000}
                  disabled={!isManager}
                  value={dailyCapDraft}
                  onChange={(e) => setDailyCapDraft(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono bg-[#0E151E] text-slate-100 border border-slate-700 rounded-lg disabled:opacity-50"
                />
              </div>
              <div>
                <label htmlFor="evap-lockout-input" className="block text-xs text-slate-400 mb-1.5">
                  Midday Evaporation Lockout Temp (°C)
                </label>
                <input
                  id="evap-lockout-input"
                  type="number"
                  min={30}
                  max={50}
                  step={1}
                  disabled={!isManager}
                  value={lockoutTempDraft}
                  onChange={(e) => setLockoutTempDraft(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono bg-[#0E151E] text-slate-100 border border-slate-700 rounded-lg disabled:opacity-50"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={!isManager}
                onClick={() => {
                  onUpdateSettings({
                    aquiferDailyCapM3: dailyCapDraft,
                    evapLockoutTempC: lockoutTempDraft,
                  });
                  setPolicySaved(true);
                  window.setTimeout(() => setPolicySaved(false), 3000);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Save Estate Sustainability Policy
              </button>
              {policySaved && (
                <span className="text-xs text-emerald-400 font-medium">
                  Policy updated across estate
                </span>
              )}
            </div>

            {isManager && teamUsers.length > 0 && (
              <div className="pt-4 border-t border-slate-800 space-y-2.5">
                <h3 className="text-xs font-semibold text-slate-300">
                  Registered Team Members (Firestore RBAC)
                </h3>
                <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg">
                  {teamUsers.map((member) => (
                    <div
                      key={member.uid}
                      className="flex items-center justify-between gap-3 px-3 py-2.5 text-xs"
                    >
                      <div>
                        <div className="font-medium text-slate-200">{member.displayName}</div>
                        <div className="font-mono text-slate-400">{member.email}</div>
                      </div>
                      <select
                        aria-label={`Role for ${member.displayName}`}
                        value={member.role}
                        onChange={(e) =>
                          void onManagerChangeUserRole(member.uid, e.target.value as UserRole)
                        }
                        className="px-2.5 py-1 text-xs bg-[#0E151E] text-slate-100 border border-slate-700 rounded-md"
                      >
                        <option value="farm_manager">Farm Manager</option>
                        <option value="field_operator">Field Operator</option>
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        {/* Field Observation Log Submission & Audit Stream */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <section className="lg:col-span-5 p-5 rounded-lg bg-[#111923] border border-slate-800">
            <h2 className="text-base font-semibold text-slate-100 mb-3">
              Submit Field Observation Log
            </h2>
            <form onSubmit={handleLogSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="log-plot" className="block text-xs text-slate-400 mb-1">
                    Plot
                  </label>
                  <select
                    id="log-plot"
                    value={plotCode}
                    onChange={(e) => setPlotCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#0E151E] text-slate-100 border border-slate-700 rounded-lg"
                  >
                    {plots.map((p) => (
                      <option key={p.id} value={p.plotCode}>
                        {p.plotCode} ({p.cropType})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="log-category" className="block text-xs text-slate-400 mb-1">
                    Category
                  </label>
                  <select
                    id="log-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as FieldLogEntry['category'])}
                    className="w-full px-3 py-2 text-xs bg-[#0E151E] text-slate-100 border border-slate-700 rounded-lg"
                  >
                    <option value="irrigation">Irrigation Action</option>
                    <option value="nozzle_check">Nozzle Inspection</option>
                    <option value="soil_sample">Soil Calibration</option>
                    <option value="weather_action">Weather Advisory</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="log-note" className="block text-xs text-slate-400 mb-1">
                  Inspection Note
                </label>
                <textarea
                  id="log-note"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Describe nozzle pressure, SMAP probe reading, or pump action..."
                  className="w-full px-3 py-2 text-xs bg-[#0E151E] text-slate-100 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-400"
                />
              </div>

              {logError && (
                <p role="alert" className="text-xs text-rose-400">
                  {logError}
                </p>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2 px-4 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors disabled:opacity-50"
              >
                {submitting ? 'Recording Log...' : 'Record Field Log'}
              </button>
            </form>
          </section>

          <section className="lg:col-span-7 p-5 rounded-lg bg-[#111923] border border-slate-800">
            <h2 className="text-base font-semibold text-slate-100 mb-3">
              Recent Field &amp; Irrigation Audit Feed
            </h2>
            {logs.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">
                No field logs recorded yet. Submit an observation on the left to begin the audit
                trail.
              </p>
            ) : (
              <ul className="divide-y divide-slate-800">
                {logs.map((entry) => (
                  <li key={entry.id} className="py-3 first:pt-0 last:pb-0 space-y-1">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold text-cyan-300">
                          {entry.plotCode}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-slate-200 font-medium">{entry.authorName}</span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-slate-400">
                          {entry.authorRole === 'farm_manager' ? 'Farm Manager' : 'Field Operator'}
                        </span>
                      </div>
                      <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                        {entry.createdAt.slice(0, 16).replace('T', ' ')}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{entry.note}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
