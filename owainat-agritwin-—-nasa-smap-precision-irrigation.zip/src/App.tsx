import { useEffect, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import { AccessLogsView } from './components/AccessLogsView';
import { AnalyticsView } from './components/AnalyticsView';
import { ThreeViewport } from './components/ThreeViewport';
import { TopBar } from './components/TopBar';
import { WeatherScheduleView } from './components/WeatherScheduleView';
import {
  ensureUserProfile,
  listTeamUsersForManager,
  persistFarmSettings,
  persistFieldLog,
  persistManagerPlotConfig,
  persistOperatorIrrigationChange,
  seedPlotsIfManager,
  signInWithGoogleAccount,
  signOutAccount,
  subscribeFieldLogs,
  subscribePlotsSync,
  subscribeToAuth,
  updateMemberRoleByManager,
} from './services/firebaseService';
import { fetchOwainatWeather } from './services/weatherService';
import {
  AnalysisLayer,
  CropType,
  FarmPlot,
  FarmSettings,
  FieldLogEntry,
  UserProfile,
  UserRole,
  WeatherForecast,
  WorkspaceTab,
} from './types/farm';
import {
  createInitialPlots,
  CROP_SPECS,
  estimateFarmBoundaries,
  generateWeatherAlerts,
  INITIAL_FARM_SETTINGS,
} from './utils/agronomy';

const INITIAL_LOGS: FieldLogEntry[] = [
  {
    id: 'seed-1',
    plotCode: 'P-03',
    authorUid: 'system-op-1',
    authorName: 'Nadia Mansour',
    authorRole: 'field_operator',
    category: 'nozzle_check',
    note: 'Outer span drop nozzles 14–18 showed partial mineral scaling; scheduled backflush before 21:00 cycle.',
    createdAt: '2026-11-14T06:20:00.000Z',
  },
  {
    id: 'seed-2',
    plotCode: 'P-02',
    authorUid: 'system-mgr-1',
    authorName: 'Dr. Hany El-Gamal',
    authorRole: 'farm_manager',
    category: 'irrigation',
    note: 'SMAP L3 surface moisture reached 0.31 m³/m³; capped P-02 flow at 280 m³/h to protect aquifer drawdown.',
    createdAt: '2026-11-14T04:45:00.000Z',
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('twin');
  const [plots, setPlots] = useState<FarmPlot[]>(() => createInitialPlots());
  const [selectedPlotId, setSelectedPlotId] = useState<string>('P-01');
  const [activeLayer, setActiveLayer] = useState<AnalysisLayer>('satellite');
  const [settings, setSettings] = useState<FarmSettings>(INITIAL_FARM_SETTINGS);
  const [logs, setLogs] = useState<FieldLogEntry[]>(INITIAL_LOGS);

  // Weather state (initialized synchronously with fallback, then hydrated via Open-Meteo)
  const [weather, setWeather] = useState<WeatherForecast>({
    latitude: 22.5833,
    longitude: 28.6667,
    source: 'climatology-fallback',
    fetchedAt: new Date().toISOString(),
    currentTempC: 36.2,
    currentWindKmh: 24,
    currentHumidityPct: 14,
    currentSolarWm2: 865,
    dailyMaxTempC: 40.4,
    dailyMinTempC: 18.8,
    hourly: [
      { timeIso: '00:00', hourLabel: '00:00', tempC: 21.4, humidityPct: 28, windKmh: 11, solarWm2: 0, et0MmHr: 0.08 },
      { timeIso: '03:00', hourLabel: '03:00', tempC: 18.8, humidityPct: 33, windKmh: 9, solarWm2: 0, et0MmHr: 0.05 },
      { timeIso: '06:00', hourLabel: '06:00', tempC: 20.1, humidityPct: 30, windKmh: 12, solarWm2: 140, et0MmHr: 0.14 },
      { timeIso: '09:00', hourLabel: '09:00', tempC: 29.6, humidityPct: 19, windKmh: 19, solarWm2: 610, et0MmHr: 0.48 },
      { timeIso: '12:00', hourLabel: '12:00', tempC: 37.8, humidityPct: 13, windKmh: 26, solarWm2: 915, et0MmHr: 0.84 },
      { timeIso: '15:00', hourLabel: '15:00', tempC: 40.4, humidityPct: 11, windKmh: 31, solarWm2: 780, et0MmHr: 0.89 },
      { timeIso: '18:00', hourLabel: '18:00', tempC: 32.5, humidityPct: 16, windKmh: 22, solarWm2: 120, et0MmHr: 0.36 },
      { timeIso: '21:00', hourLabel: '21:00', tempC: 25.2, humidityPct: 24, windKmh: 14, solarWm2: 0, et0MmHr: 0.12 },
    ],
  });

  // Firebase Auth & RBAC state
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authProfile, setAuthProfile] = useState<UserProfile | null>(null);
  const [previewRole, setPreviewRole] = useState<UserRole>('farm_manager');
  const [authError, setAuthError] = useState<string | null>(null);
  const [teamUsers, setTeamUsers] = useState<UserProfile[]>([]);

  const effectiveRole: UserRole = authProfile ? authProfile.role : previewRole;

  useEffect(() => {
    void fetchOwainatWeather().then((res) => setWeather(res));
  }, []);

  useEffect(() => {
    const unsub = subscribeToAuth((user) => {
      setFirebaseUser(user);
      if (!user) {
        setAuthProfile(null);
        setTeamUsers([]);
        return;
      }
      void ensureUserProfile(user)
        .then(async (profile) => {
          setAuthProfile(profile);
          if (profile.role === 'farm_manager') {
            await seedPlotsIfManager(createInitialPlots(), user);
            const members = await listTeamUsersForManager();
            setTeamUsers(members);
          }
        })
        .catch((err) => {
          setAuthError(err instanceof Error ? err.message : 'Unable to load user profile');
        });
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!firebaseUser || !authProfile) return;
    const unsubPlots = subscribePlotsSync(
      (patches) => {
        setPlots((prev) =>
          prev.map((plot) => {
            const patch = patches[plot.plotCode];
            if (!patch) return plot;
            return { ...plot, ...patch };
          }),
        );
      },
      () => {
        // Keep local plots if offline or permission pending
      },
    );

    const unsubLogs = subscribeFieldLogs(
      firebaseUser.uid,
      authProfile.role,
      (remoteLogs) => {
        if (remoteLogs.length > 0) {
          setLogs(remoteLogs);
        }
      },
      () => {},
    );

    return () => {
      unsubPlots();
      unsubLogs();
    };
  }, [firebaseUser, authProfile]);

  const boundary = useMemo(() => estimateFarmBoundaries(plots), [plots]);
  const alerts = useMemo(
    () => generateWeatherAlerts(weather, settings.evapLockoutTempC),
    [weather, settings.evapLockoutTempC],
  );

  const handleToggleIrrigation = (plotId: string, nextIrrigating: boolean, nextFlow: number) => {
    const targetPlot = plots.find((p) => p.id === plotId);
    if (!targetPlot) return;

    const clampedFlow = nextIrrigating
      ? Math.min(targetPlot.sustainabilityCapM3Hr, Math.max(80, Math.round(nextFlow)))
      : 0;

    setPlots((prev) =>
      prev.map((p) => {
        if (p.id !== plotId) return p;
        return {
          ...p,
          irrigating: nextIrrigating,
          flowRateM3Hr: clampedFlow,
          smapSurfaceMoisture: nextIrrigating
            ? Number(Math.min(0.36, p.smapSurfaceMoisture + 0.02).toFixed(2))
            : p.smapSurfaceMoisture,
        };
      }),
    );

    if (firebaseUser) {
      void persistOperatorIrrigationChange(
        targetPlot,
        nextIrrigating,
        clampedFlow,
        firebaseUser.uid,
      );
    }
  };

  const handleManagerUpdatePlot = (
    plotId: string,
    updates: {
      cropType: CropType;
      targetMoisturePct: number;
      sustainabilityCapM3Hr: number;
    },
  ) => {
    if (effectiveRole !== 'farm_manager') return;
    const targetPlot = plots.find((p) => p.id === plotId);
    if (!targetPlot) return;

    const isFallow = updates.cropType === 'Fallow';
    const nextIrrigating = isFallow ? false : targetPlot.irrigating;
    const nextFlow = isFallow
      ? 0
      : Math.min(targetPlot.flowRateM3Hr, updates.sustainabilityCapM3Hr);

    setPlots((prev) =>
      prev.map((p) => {
        if (p.id !== plotId) return p;
        return {
          ...p,
          cropType: updates.cropType,
          targetMoisturePct: updates.targetMoisturePct,
          sustainabilityCapM3Hr: updates.sustainabilityCapM3Hr,
          irrigating: nextIrrigating,
          flowRateM3Hr: nextFlow,
          dailyEtcMm: CROP_SPECS[updates.cropType].baseEtcMm,
          ndvi: isFallow ? 0.12 : Math.max(0.58, p.ndvi),
        };
      }),
    );

    if (firebaseUser) {
      void persistManagerPlotConfig(
        targetPlot,
        {
          cropType: updates.cropType,
          targetMoisturePct: updates.targetMoisturePct,
          sustainabilityCapM3Hr: updates.sustainabilityCapM3Hr,
          irrigating: nextIrrigating,
          flowRateM3Hr: nextFlow,
        },
        firebaseUser.uid,
      );
    }
  };

  const handleUpdateSettings = (next: FarmSettings) => {
    if (effectiveRole !== 'farm_manager') return;
    setSettings(next);
    if (firebaseUser) {
      void persistFarmSettings(next, firebaseUser.uid);
    }
  };

  const handleSubmitLog = async (entry: {
    plotCode: string;
    category: FieldLogEntry['category'];
    note: string;
  }) => {
    const newEntry: FieldLogEntry = {
      id: `local-${Date.now()}`,
      plotCode: entry.plotCode,
      authorUid: firebaseUser?.uid ?? 'local-preview',
      authorName:
        authProfile?.displayName ??
        (effectiveRole === 'farm_manager' ? 'Farm Manager' : 'Field Operator'),
      authorRole: effectiveRole,
      category: entry.category,
      note: entry.note,
      createdAt: new Date().toISOString(),
    };
    setLogs((prev) => [newEntry, ...prev]);

    if (firebaseUser && authProfile) {
      await persistFieldLog({
        plotCode: newEntry.plotCode,
        authorUid: firebaseUser.uid,
        authorName: authProfile.displayName,
        authorRole: authProfile.role,
        category: newEntry.category,
        note: newEntry.note,
      });
    }
  };

  const handleSignInGoogle = async () => {
    setAuthError(null);
    try {
      const profile = await signInWithGoogleAccount();
      setAuthProfile(profile);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : 'Google sign-in popup was closed or blocked.',
      );
    }
  };

  const handleSignOut = async () => {
    await signOutAccount();
    setAuthProfile(null);
  };

  const handleManagerChangeUserRole = async (uid: string, role: UserRole) => {
    await updateMemberRoleByManager(uid, role);
    const updated = await listTeamUsersForManager();
    setTeamUsers(updated);
  };

  return (
    <div
      data-role={effectiveRole}
      data-tab={activeTab}
      className="h-screen w-screen flex flex-col bg-[#0B1117] text-slate-100 overflow-hidden"
    >
      <TopBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        effectiveRole={effectiveRole}
        authUser={authProfile}
        onOpenRolePanel={() => setActiveTab('access')}
      />

      <main className="flex-1 min-h-0 flex flex-col overflow-hidden">
        {activeTab === 'twin' && (
          <ThreeViewport
            plots={plots}
            selectedPlotId={selectedPlotId}
            onSelectPlot={setSelectedPlotId}
            activeLayer={activeLayer}
            onChangeLayer={setActiveLayer}
            boundary={boundary}
            effectiveRole={effectiveRole}
            onToggleIrrigation={handleToggleIrrigation}
            onManagerUpdatePlot={handleManagerUpdatePlot}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            plots={plots}
            boundary={boundary}
            settings={settings}
            weather={weather}
            alerts={alerts}
            onSelectPlotInTwin={(plotId) => {
              setSelectedPlotId(plotId);
              setActiveTab('twin');
            }}
          />
        )}

        {activeTab === 'weather' && (
          <WeatherScheduleView
            weather={weather}
            alerts={alerts}
            plots={plots}
            settings={settings}
            onToggleIrrigation={handleToggleIrrigation}
          />
        )}

        {activeTab === 'access' && (
          <AccessLogsView
            authUser={authProfile}
            effectiveRole={effectiveRole}
            onChangePreviewRole={setPreviewRole}
            onSignInGoogle={handleSignInGoogle}
            onSignOut={handleSignOut}
            authError={authError}
            plots={plots}
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            logs={logs}
            onSubmitLog={handleSubmitLog}
            teamUsers={teamUsers}
            onManagerChangeUserRole={handleManagerChangeUserRole}
          />
        )}
      </main>
    </div>
  );
}
